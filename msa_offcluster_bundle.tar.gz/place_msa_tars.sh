#!/bin/bash
# place_msa_tars.sh - install off-cluster MSA tarballs so boltz converts them
# locally with ZERO server contact.
#
# Mechanism (boltz 2.2.1): compute_msa() calls run_mmseqs2 with prefix
#   <out_dir>/boltz_results_<name>/msa/<name>_unpaired_tmp
# and run_mmseqs2 skips submit/poll/download when
#   <prefix>_env/out.tar.gz
# already exists; extraction + CSV conversion then run locally, byte-identical
# to a live run (the tar.gz IS the complete server product).
#
# Usage (on the cluster, repo root = ~/scratch/OC):
#   1) copy msa_tars/ (with <name>.tar.gz + jobs.csv) into $REPO
#   2) bash place_msa_tars.sh "$PWD"
#   3) qsub submit_msagen3.sh        # msagen3.sh now needs no server
#
# Guards: verifies the sequence in yamls/<name>.yaml matches jobs.csv and that
# each tarball contains the env-mode a3m pair before placing anything.

set -uo pipefail
REPO="${1:-$PWD}"
TARDIR="${2:-$REPO/msa_tars}"
JOBS="$TARDIR/jobs.csv"
cd "$REPO"
[ -f "$JOBS" ] || { echo "jobs.csv not found at $JOBS"; exit 1; }

n_ok=0; n_fail=0
while IFS=, read -r name seq; do
  [ "$name" = "name" ] && continue
  tar="$TARDIR/$name.tar.gz"
  yaml="yamls/$name.yaml"
  if [ ! -f "$tar" ];  then echo "[FAIL] $name: $tar missing";  n_fail=$((n_fail+1)); continue; fi
  if [ ! -f "$yaml" ]; then echo "[FAIL] $name: $yaml missing"; n_fail=$((n_fail+1)); continue; fi
  yseq=$(awk '/^[[:space:]]*sequence:/{print $2; exit}' "$yaml")
  if [ "$yseq" != "$seq" ]; then
    echo "[FAIL] $name: sequence mismatch between $yaml and jobs.csv - NOT placing"
    n_fail=$((n_fail+1)); continue
  fi
  if ! tar tzf "$tar" 2>/dev/null | grep -q 'uniref.a3m'; then
    echo "[FAIL] $name: $tar is not a valid MSA tarball"; n_fail=$((n_fail+1)); continue
  fi
  d="results_msagen_$name/boltz_results_$name/msa/${name}_unpaired_tmp_env"
  mkdir -p "$d"
  cp -n "$tar" "$d/out.tar.gz" 2>/dev/null || cp "$tar" "$d/out.tar.gz"
  echo "[ok] $name -> $d/out.tar.gz"
  n_ok=$((n_ok+1))
done < "$JOBS"
echo "placed=$n_ok failed=$n_fail"
[ "$n_fail" -eq 0 ]
