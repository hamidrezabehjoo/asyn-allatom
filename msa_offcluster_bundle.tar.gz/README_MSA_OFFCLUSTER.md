# Off-cluster MSA fetch (Track 3 fix for the api.colabfold.com throttle)

The cluster's shared egress IP is being dropped at TCP level by
api.colabfold.com (provoked by our own polling bursts). The throttle keys on
source IP — any non-cluster machine is unaffected. This package moves the
server contact off-cluster while keeping the conversion byte-identical to a
live run.

## Why this is byte-perfect

boltz 2.2.1 (`src/boltz/data/msa/mmseqs2.py`) runs:

```python
tar_gz_file = f"{prefix}_{mode}/out.tar.gz"      # prefix = msa/<target>_unpaired_tmp, mode = "env"
if not os.path.isfile(tar_gz_file):
    ... submit / poll / download ...             # <-- the ONLY server contact
with tarfile.open(tar_gz_file) as tar_gz:        # unconditional: local extraction
    tar_gz.extractall(path)
```

If `out.tar.gz` already exists, the server is skipped entirely and the same
extraction/conversion runs locally. The tarball IS the complete server
product, so a pre-placed tarball makes the on-cluster run identical to a live
one. No format conversion is done by this package — boltz itself converts.

## Files

- `msa_fetch_offcluster.py` — standalone fetcher (stdlib only). Replicates
  boltz's exact client protocol (POST ticket/msa, mode=env, User-Agent: boltz)
  with polite pacing (~15–20 s polls, 30 s between targets), resume support,
  and per-tarball integrity verification (members + query sequence match).
- `jobs.csv` — the 14 missing targets: panel 3 (t4l, cam, glnbp, mad2, xcl1,
  mbp) and panel 2 (tm_0287, slc1a1_out, ptsg, a5u30_003247, murj, tt_c0976,
  spf1, tm_0287v2). Sequences are identical to the yamls (panel-2 sequences
  re-derived from ref1 PDB SEQRES with the pinned fetch_panel.py logic).
- `place_msa_tars.sh` — cluster-side placement with sequence-mismatch guard.
- `msa_tars/` — (as produced) `<name>.tar.gz` + `MSA_TARS.md5`.

## If you run the fetcher yourself (laptop / any non-cluster machine)

```bash
python3 msa_fetch_offcluster.py jobs.csv --outdir msa_tars --pace 30 --poll 15
md5sum -c msa_tars/MSA_TARS.md5
```

Resumable: re-running skips verified tarballs. Runtime ≈ 1–1.5 h for 14 targets.

## On the cluster

```bash
cd ~/scratch/OC
# copy msa_tars/ + jobs.csv + place_msa_tars.sh here (e.g. scp -r)
bash place_msa_tars.sh "$PWD"
# expect: placed=14 failed=0
qsub submit_msagen3.sh      # boltz now converts locally; zero server contact
```

After msagen3 finishes, verify the freeze:

```bash
ls panel_msa/{t4l,cam,glnbp,mad2,xcl1,mbp,tm_0287,slc1a1_out,ptsg,a5u30_003247,murj,tt_c0976,spf1,tm_0287v2}.a3m
```

Then proceed as registered: panel 3 `qsub -v PHASE=screen,REPO="$PWD" submit_panel3.sh`;
panel 2 screen for the remaining 8.

## Optional: verify your installed boltz matches the assumed convention

```bash
python3 - <<'EOF'
import inspect
from boltz.data.msa import mmseqs2
src = inspect.getsource(mmseqs2.run_mmseqs2)
print([l.strip() for l in src.splitlines() if 'tar_gz_file' in l or 'extractall' in l])
EOF
```

Expected: the `isfile(tar_gz_file)` guard wraps only submit/poll/download and
`extractall` runs unconditionally. That is what this package relies on.
