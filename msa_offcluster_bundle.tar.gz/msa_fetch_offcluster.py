#!/usr/bin/env python3
"""msa_fetch_offcluster.py - standalone off-cluster ColabFold MSA fetcher.

Purpose: the cluster's shared egress IP is being TCP-throttled by
api.colabfold.com (provoked by our own polling bursts). The throttle keys on
source IP, so any NON-cluster machine (laptop, workstation, cloud VM) is
unaffected. This script runs off-cluster and downloads the server product
(out.tar.gz) for each msagen target. The tarballs are then placed on the
cluster where boltz's own code extracts/converts them locally - boltz skips
the server entirely when {target}_unpaired_tmp_env/out.tar.gz already exists
(boltz 2.2.1, src/boltz/data/msa/mmseqs2.py: `if not os.path.isfile(tar_gz_file)`;
extraction/parsing happens unconditionally afterwards). Byte-perfect fidelity
with a live run is therefore guaranteed by construction.

Server interaction exactly replicates boltz's client protocol:
    POST {host}/ticket/msa           data={"q": ">101\nSEQ\n", "mode": "env"}
                                     header User-Agent: boltz
    poll GET {host}/ticket/{ID}      until status COMPLETE
    GET  {host}/result/download/{ID} -> out.tar.gz
but paced politely (poll every ~15-20 s, pause between targets), resumable,
and with integrity verification of every tarball.

Stdlib only - runs anywhere with python3.

Usage:
    python3 msa_fetch_offcluster.py jobs.csv --outdir msa_tars [--pace 30] [--poll 15]

jobs.csv columns: name,sequence   (header required; one protein per row)
Outputs: <outdir>/<name>.tar.gz  +  <outdir>/MSA_TARS.md5
Existing verified tarballs are skipped (resumable: safe to re-run).
Exit code 0 iff every target has a verified tarball.
"""

import argparse
import csv
import hashlib
import json
import os
import random
import sys
import tarfile
import time
import urllib.parse
import urllib.request

HOST = "https://api.colabfold.com"
UA = {"User-Agent": "boltz"}  # identical to boltz's client
EXPECTED_MEMBERS = ("uniref.a3m", "bfd.mgnify30.metaeuk30.smag30.a3m")  # mode "env"


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def req(url, data=None, timeout=45):
    r = urllib.request.Request(url, data=data, headers=UA)
    return urllib.request.urlopen(url=r, timeout=timeout)


def submit(seq):
    q = f">101\n{seq}\n"  # N=101, exactly as boltz submits a single sequence
    data = urllib.parse.urlencode({"q": q, "mode": "env"}).encode()
    for attempt in range(1, 31):
        try:
            with req(f"{HOST}/ticket/msa", data=data, timeout=60) as r:
                out = json.loads(r.read().decode())
        except Exception as e:
            log(f"    submit error ({e}); retry {attempt}/30 after 30 s")
            time.sleep(30)
            continue
        st = out.get("status", "ERROR")
        if st in ("UNKNOWN", "RATELIMIT"):
            wait = 30 + random.randint(0, 30)
            log(f"    submit status {st}; waiting {wait}s")
            time.sleep(wait)
            continue
        if st == "MAINTENANCE":
            log("    server MAINTENANCE; waiting 300 s")
            time.sleep(300)
            continue
        if st == "ERROR":
            raise RuntimeError("server rejected the sequence (status ERROR)")
        return out["id"]
    raise RuntimeError("submit: too many attempts")


def poll(job_id, poll_s, max_s=5400):
    t0 = time.time()
    while True:
        try:
            with req(f"{HOST}/ticket/{job_id}", timeout=30) as r:
                out = json.loads(r.read().decode())
        except Exception as e:
            log(f"    poll error ({e}); retrying in 30 s")
            time.sleep(30)
            continue
        st = out.get("status", "ERROR")
        if st == "COMPLETE":
            return
        if st == "ERROR":
            raise RuntimeError("job failed on server (status ERROR)")
        if st == "MAINTENANCE":
            time.sleep(120)
        else:
            if time.time() - t0 > max_s:
                raise RuntimeError(f"job still {st} after {max_s}s")
            time.sleep(poll_s + random.uniform(0, 5))


def download(job_id, dest):
    part = dest + ".part"
    for attempt in range(1, 6):
        try:
            with req(f"{HOST}/result/download/{job_id}", timeout=600) as r, \
                    open(part, "wb") as f:
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
            os.replace(part, dest)  # never leave a partial file under the final name
            return
        except Exception as e:
            log(f"    download error ({e}); retry {attempt}/5 after 20 s")
            if os.path.exists(part):
                os.remove(part)
            time.sleep(20)
    raise RuntimeError("download: too many attempts")


def verify(path, seq):
    """Tarball must be a valid gzip tar containing both env-mode a3m files,
    and the uniref query header must be our submitted id (>101)."""
    try:
        with tarfile.open(path) as tf:
            names = {m.name.lstrip("./") for m in tf.getmembers()}
            for want in EXPECTED_MEMBERS:
                if want not in names:
                    return f"missing member {want}"
                data = tf.extractfile(want).read()
                if len(data) < 100:
                    return f"member {want} suspiciously small ({len(data)} B)"
                if want == "uniref.a3m":
                    head = data[:64].decode(errors="replace")
                    if not head.startswith(">101"):
                        return f"uniref.a3m query header unexpected: {head[:32]!r}"
                    first_seq = data.split(b"\n")[1].decode().strip()
                    if first_seq != seq:
                        return "uniref.a3m query sequence != submitted sequence"
    except Exception as e:
        return f"not a valid tar.gz ({e})"
    return None


def md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("jobs", help="jobs.csv with columns name,sequence")
    ap.add_argument("--outdir", default="msa_tars")
    ap.add_argument("--pace", type=float, default=30,
                    help="seconds between targets (default 30)")
    ap.add_argument("--poll", type=float, default=15,
                    help="base seconds between status polls (default 15)")
    a = ap.parse_args()

    os.makedirs(a.outdir, exist_ok=True)
    with open(a.jobs) as f:
        jobs = [(r["name"].strip(), r["sequence"].strip())
                for r in csv.DictReader(f)]
    log(f"{len(jobs)} targets from {a.jobs}; outdir={a.outdir}")

    failures = {}
    done_count = 0
    for i, (name, seq) in enumerate(jobs):
        dest = os.path.join(a.outdir, f"{name}.tar.gz")
        if os.path.isfile(dest):
            err = verify(dest, seq)
            if err is None:
                log(f"[{i+1}/{len(jobs)}] {name}: already present and verified, skipping")
                continue
            log(f"[{i+1}/{len(jobs)}] {name}: existing tarball failed verify ({err}); refetching")
            os.remove(dest)
        elif done_count and a.pace > 0:
            log(f"    pacing {a.pace:.0f}s before next target")
            time.sleep(a.pace)
        try:
            log(f"[{i+1}/{len(jobs)}] {name} ({len(seq)} aa): submitting")
            job_id = submit(seq)
            log(f"    job id {job_id}; polling")
            poll(job_id, a.poll)
            log(f"    COMPLETE; downloading")
            download(job_id, dest)
            err = verify(dest, seq)
            if err is not None:
                os.remove(dest)
                raise RuntimeError(f"verify failed: {err}")
            done_count += 1
            log(f"    ok: {dest} ({os.path.getsize(dest)} B, md5 {md5(dest)})")
        except Exception as e:
            failures[name] = str(e)
            log(f"    FAILED: {e}")

    with open(os.path.join(a.outdir, "MSA_TARS.md5"), "w") as f:
        for name, seq in jobs:
            p = os.path.join(a.outdir, f"{name}.tar.gz")
            if os.path.isfile(p) and verify(p, seq) is None:
                f.write(f"{md5(p)}  {name}.tar.gz\n")

    if failures:
        log(f"DONE with {len(failures)} failures: {sorted(failures)}")
        return 1
    log(f"DONE: all {len(jobs)} tarballs verified in {a.outdir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
