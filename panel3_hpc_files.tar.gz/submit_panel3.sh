#!/usr/bin/env bash
#PBS -N diffusion_panel3
#PBS -P 11004454
#PBS -q normal
#PBS -l select=1:ncpus=8:ngpus=2
#PBS -l walltime=24:00:00
#PBS -j oe
# ============================================================================
# Panel-3 job (registered scope-condition test) — NSCC ASPIRE 2A.
# Submit from the repo root (REPO override if it lives elsewhere):
#
#   qsub -v PHASE=fetch,REPO="$PWD"   submit_panel3.sh   # refs/yamls (needs network; else run on login node)
#   qsub -v PHASE=screen,REPO="$PWD"  submit_panel3.sh   # stock screen + diagnosis + MSAs
#   qsub -v PHASE=ladder,REPO="$PWD"  submit_panel3.sh   # dose ladder (4 doses x 5 seeds, all targets)
#   qsub -v PHASE=analyze,REPO="$PWD" submit_panel3.sh   # E1/E2/E3 scope verdicts
#   qsub -v PHASE=all,REPO="$PWD"     submit_panel3.sh   # screen + manifest + ladder + analyze, in order
#
# PRECONDITION: panel/PANEL3_REGISTRATION.md committed BEFORE the first
# screen run. The git commit is the prospective timestamp.
#
# Everything is resumable: finished seeds/doses print [skip]; a walltime
# kill means: fix the cause, resubmit the same PHASE. Nothing redone.
#
# Panel-3 targets are small (56-370 aa): --max_parallel_samples 30 is fine.
# The MSA server timeout patch (mmseqs2.py) must be in place, same as panel 2.
# ============================================================================
set -euo pipefail

PHASE="${PHASE:-screen}"
case "$PHASE" in fetch|screen|ladder|analyze|all) ;; *)
    echo "FATAL: PHASE must be fetch|screen|ladder|analyze|all (got '$PHASE')" >&2
    exit 2 ;;
esac

SCRATCH="${SCRATCH:-/scratch/users/industry/ism/behjoo}"
ENV_PREFIX="${ENV_PREFIX:-$SCRATCH/envs/boltz_ctrl}"
REPO="${REPO:-$HOME/DiffusionControl}"

# caches on scratch (batch jobs do not read ~/.bashrc)
export PIP_CACHE_DIR="$SCRATCH/pipcache" TMPDIR="$SCRATCH/tmp" XDG_CACHE_HOME="$SCRATCH/cache"

source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$ENV_PREFIX"
export LD_LIBRARY_PATH="$CONDA_PREFIX/lib/python3.11/site-packages/nvidia/nvrtc/lib:${LD_LIBRARY_PATH:-}"

cd "$REPO"

# knobs — GPUS follows the actual allocation
GPUS="${GPUS:-$(nvidia-smi -L 2>/dev/null | grep -c '^GPU' || echo 1)}"
export GPUS
export BOLTZ_EXTRA_ARGS="${BOLTZ_EXTRA_ARGS:---max_parallel_samples 30}"
# frozen by the panel-3 registration (do NOT set): N STEPS SEEDS CTRL_SEEDS DOSES

echo "== panel-3 job =="
echo "  job     : ${PBS_JOBID:-interactive}"
echo "  node    : $(hostname)   phase: $PHASE   gpus: $GPUS"
echo "  extra   : ${BOLTZ_EXTRA_ARGS:-<none>}"
nvidia-smi --query-gpu=index,name,memory.total --format=csv,noheader || true

echo "== registration check =="
if [ "$PHASE" != "fetch" ]; then
    git log --oneline -1 -- panel/PANEL3_REGISTRATION.md || true
    git ls-files --error-unmatch panel/PANEL3_REGISTRATION.md >/dev/null 2>&1 \
        || { echo "FATAL: PANEL3_REGISTRATION.md is not tracked by git -"; echo "commit it BEFORE any screen/ladder run."; exit 1; }
    git diff --quiet panel/PANEL3_REGISTRATION.md && git diff --cached --quiet panel/PANEL3_REGISTRATION.md \
        || { echo "FATAL: PANEL3_REGISTRATION.md has uncommitted changes - commit BEFORE running"; exit 1; }
fi

echo "== freeze checks =="
python3 panel/make_manifest.py --verify    # panel-1 freeze must stay intact
python3 panel/make_manifest2.py --verify   # panel-2 freeze (once written)
python3 panel/make_manifest3.py --verify   # panel-3 freeze (once written)

case "$PHASE" in
    fetch)   bash panel/run_panel3.sh fetch ;;
    screen)  bash panel/run_panel3.sh screen ;;
    ladder)  bash panel/run_panel3.sh ladder ;;
    analyze) bash panel/run_panel3.sh analyze ;;
    all)     bash panel/run_panel3.sh screen \
          && python3 panel/make_manifest3.py \
          && bash panel/run_panel3.sh ladder \
          && bash panel/run_panel3.sh analyze ;;
esac

echo "== done: $PHASE =="
echo "REMINDER: scratch purges at 30 days — copy results/, eval_*.csv and"
echo "          panel_msa/<scope3>.a3m back to the paper repo now."
