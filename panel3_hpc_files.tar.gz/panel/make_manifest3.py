#!/usr/bin/env python3
"""Write or verify the PANEL-3 freeze manifest (PANEL3_REGISTRATION.md).

    python3 panel/make_manifest3.py            # write panel/MANIFEST3.md5
    python3 panel/make_manifest3.py --verify   # check current files against it

Panel-3 counterpart of make_manifest.py / make_manifest2.py. Pins only what
the panel-3 scope test depends on:

  - panel/targets3.csv, panel/run_panel3.sh, panel/analyze_panel3.py
  - the shared frozen machinery (eval_panel.py, panel_diagnose.py,
    diffusionv2.py -- also pinned by panel/MANIFEST.md5; re-pinned here so
    MANIFEST3 is self-contained)
  - panel/fetch_report3.csv + panel/fetch_report3_dev.csv and the targets'
    yamls, prepared references, and frozen MSAs (MSAs exist only AFTER the
    screen phase; write the manifest once after screening, verify ever after)

PANEL3_REGISTRATION.md is deliberately NOT pinned (same design as panels
1-2): the post-archival fields are filled in after the tag. The tag
panel-v4 is the timestamp.

Write-timing rule: run `make_manifest3.py` (write mode) ONCE, after
fetch+screen complete and before ladder. Never re-run write mode after
ladder arms have started.
"""

import argparse
import csv
import hashlib
import os
import sys

MANIFEST = os.path.join("panel", "MANIFEST3.md5")

FIXED = [
    "panel/targets3.csv",
    "panel/run_panel3.sh",
    "panel/analyze_panel3.py",
    "panel/eval_panel.py",
    "panel/panel_diagnose.py",
    "panel/fetch_report3.csv",
    "panel/fetch_report3_dev.csv",
    "diffusionv2.py",
]


def md5(path):
    return hashlib.md5(open(path, "rb").read()).hexdigest()


def collect():
    files = list(FIXED)
    for r in csv.DictReader(open(os.path.join("panel", "targets3.csv"))):
        if r["status"] not in ("ready", "dev"):
            continue
        n = r["name"]
        files += [
            os.path.join("yamls", f"{n}.yaml"),
            os.path.join("panel_data", f"{n}_ref1.pdb"),
            os.path.join("panel_data", f"{n}_ref2.pdb"),
            os.path.join("panel_msa", f"{n}.a3m"),   # present after screen
        ]
    return sorted(set(files))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verify", action="store_true")
    args = ap.parse_args()

    if not args.verify:
        files = [f for f in collect() if os.path.exists(f)]
        missing = [f for f in collect() if not os.path.exists(f)]
        with open(MANIFEST, "w") as f:
            for p in files:
                f.write(f"{md5(p)}  {p}\n")
        print(f"wrote {MANIFEST} ({len(files)} files)")
        if missing:
            print("NOTE: not yet present (run write mode again only if NO "
                  "ladder arm has started):")
            for p in missing:
                print(f"  pending {p}")
        return

    if not os.path.exists(MANIFEST):
        print(f"{MANIFEST} not found (pre-freeze; nothing to verify)")
        return
    bad = missing = 0
    for line in open(MANIFEST):
        line = line.rstrip("\n")
        if not line:
            continue
        want, path = line.split(None, 1)
        path = path.strip()
        if not os.path.exists(path):
            print(f"MISSING  {path}")
            missing += 1
        elif md5(path) != want:
            print(f"CHANGED  {path}")
            bad += 1
    if bad or missing:
        sys.exit(f"VERIFY FAILED: {bad} changed, {missing} missing")
    print("manifest3 OK: all pinned panel-3 files match")


if __name__ == "__main__":
    main()
