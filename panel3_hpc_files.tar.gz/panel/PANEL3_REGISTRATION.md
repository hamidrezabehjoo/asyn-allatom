# Panel 3 registration — scope-condition test (amendment to the prospective panel protocol v2.5)

**Status: DRAFT — commit BEFORE the first panel-3 run. The commit timestamp
is the prospective timestamp; any panel-3 screening output that predates
this commit invalidates the design.**

This amendment registers the third prospective panel. Panels 1 and 2 ask
"does the controller work, prospectively?" Panel 3 asks the sharper
question the panel-1 results raised: **can we predict, from the two
reference structures alone and before any simulation, which proteins the
controller can steer and which it cannot?** Every classification,
prediction, and endpoint below is frozen before the first panel-3
screening run.

## 1. Population and frozen classification (stated before screening)

**Classification rule (mechanical, computed from the reference PDB entries
only — no simulation output is used).** For each target, from the deposited
HELIX/SHEET records of the two reference entries (±1-residue boundary
erosion against depositor noise) and from the HETATM records:

- **f_ss** = fraction of shared aligned residues whose secondary-structure
  class (H/E/C) differs between the two reference states.
- **ligand-gated** = either reference contains a buried organic ligand in
  the state-defining cleft: a non-water HETATM group with >= 8 heavy atoms
  and >= 20 protein-chain atoms within 5 A. (Metal ions, water, and small
  crystallization buffers cannot trigger this rule.)
- **Class B (refold)**: f_ss >= 0.15 — the states differ by secondary-
  structure reorganization.
- **Class C (hinge, locked)**: f_ss < 0.15 and ligand-gated — hinge-like
  motion, but one endpoint's state is stabilized by a bound ligand.
- **Class A (hinge, free)**: f_ss < 0.15 and not ligand-gated.

Applied on 2026-10-14 (analysis of reference structures only, sandbox
pipeline = fetch_panel.py + the rule above; no Boltz run of any panel-3
target preceded it except the explicitly dev-labelled cases):

| target | pair | ref_rmsd | f_ss | buried ligand | class |
|---|---|---|---|---|---|
| t4l  | 172L(A) open / 2LZM(A) closed | 3.32 A | 0.043 | none | A |
| cam  | 1CLL(A) extended / 1CFD(A) compact | 10.83 A | 0.146 | none (Ca2+ ions) | A |
| glnbp | 1GGG(A) open / 1WDN(A) closed | 5.34 A | 0.050 | GLN in closed (63 contacts) | C |
| mad2 | 1DUJ(A) O / 1S2H(A) C | 10.82 A | 0.171 | none | B |
| xcl1 | 1J8I(A) Ltn10 / 2JP1(A) Ltn40 | 12.96 A | 0.283 | none | B |
| gagswitch | 2KDL(A) GA95 / 2KDM(A) GB95 | 12.79 A | 0.786 | none | B |
| mbp (dev) | 1OMP(A) open / 1ANF(A) closed | 3.77 A | 0.143 | GLC x2 in closed | C |
| kaib (dev) | 2QKE(A) ground / 5JYT(A) fold-switch | 9.38 A | 0.398 | none | B |

Notes on the selections (fixed here, before screening):

- **t4l**: the open reference is 172L chain A (I3C, closure -37 deg in the
  literature hinge-angle table), the M6I-family copy furthest from WT
  closed (2LZM). The commonly cited 150L entry contains four chains
  spanning 0.9-2.6 A of opening; its chain A is a closed copy and is NOT
  used. Input sequence = UniProt WT (P00720); mutant references pass the
  identity gate (id >= 0.96).
- **gagswitch** (GA95/GB95 designed pair): ref2 identity to the input is
  0.946, below the frozen 0.95 fetch gate; it is EXPECTED to be excluded
  at fetch (same rule that excluded mfsd2a_out/aac3_out in panel 2). The
  gate decides; the row stays in targets3.csv so the decision is
  mechanical.
- **xcl1**: the Ltn40 reference is a subunit of the physiological dimer;
  the prediction input is the monomer. The class-B prediction (below) is
  unaffected: it states the monomer will not be steered into the Ltn40
  fold, for whatever reason (refold barrier or missing dimer partner).
- **mbp** and **kaib** are dev-labelled (used during method development /
  the 2026-10-14 exploratory transfer test). They run the identical
  protocol and are reported descriptively, never in the E1/E2/E3 tallies.

**Tally population (non-dev): t4l, cam (A); glnbp (C); mad2, xcl1 (B)**
— 5 targets. Dev: mbp, kaib.

**Gate result (2026-10-15, before any screening).** The fetch was executed
with the pinned `fetch_panel.py` in an off-cluster sandbox (the login
node's python urllib egress hangs while curl works; the pipeline is
deterministic — a regeneration check on the kaib refs reproduced the
earlier HPC files byte-identically — and every product is pinned in
MANIFEST3.md5). Result: **gagswitch ref2 identity 0.946 < 0.95 →
VALIDATION_FAIL → excluded before screening**, exactly as registered
above. xcl1 ref2 covers 60 of 93 input positions (Ltn40 construct
boundaries; id = 1.00, passes). All other ready targets pass with
id >= 0.98. Fetch diagnostics: panel/fetch_report3.csv (committed with
this registration).

## 2. Frozen predictions (before any panel-3 data)

Master claim (the scope condition): **a target is controllable by
nu-scheduling if and only if (i) its two states differ by hinge-like
motion with conserved secondary structure (class A) and (ii) both basins
are populated in the stock ensemble.** Class C predicts failure of (ii)
by ligand-lock (panel-1 PotF precedent); class B predicts failure by the
refolding barrier (panel-1 rfah precedent).

- **E1 (class-A controllability).** For every class-A tally target, the
  dose ladder produces a significant monotone response of the ref1-basin
  (open/extended) occupancy against log2(alpha): one-sided permutation
  p < 0.05 on the Spearman correlation AND an extreme-dose occupancy
  difference Delta = frac_ref1(alpha=2.5) - frac_ref1(alpha=0.25) >= 0.10.
  E1 passes iff ALL class-A tally targets are individually significant
  and the Fisher-combined p < 0.05.
- **E2 (scope boundary / falsification).** No class-B or class-C tally
  target shows a significant dose-response (two-sided permutation p,
  Holm-corrected within the B+C set, AND |Delta| >= 0.10). E2 passes iff
  there are zero violations. A violation falsifies the scope rule as
  stated and is reported as such.
- **E3 (reachability sub-predictions, per class).** In the stock screen
  (300 samples): class A — BOTH basins >= 5%; class C — ref2 (locked)
  basin < 5%; class B — ref2 (alternative fold) basin < 5%. Reported as
  correct/total with an exact binomial test against chance (p0 = 0.5).
- **Dev consistency (outside all tallies).** mbp: class-C behaviour
  (locked closed basin, flat ladder). kaib: class-B behaviour (ground-
  state collapse, flat ladder) — the 2026-10-14 exploratory run is the
  preliminary observation; the panel-3 ladder is the systematic version.

Sign convention (fixed, from the panel-1 sign law): ref1 is the
open/extended/ground state for every target; boost (alpha > 1) enriches
ref1, damp (alpha < 1) enriches ref2 (closed/compact). The E1 statistic
is the slope of frac_ref1 vs log2(alpha), predicted positive.

## 3. Frozen settings

Identical to panel 2 unless listed: N=100 diffusion samples; 200 sampling
steps; screen seeds 42 1 2 (300 stock samples per target, diagnosis +
MSA freeze); arm seeds 42 1 2 7 13; NU_TW=0.5; `--use_potentials`;
PDB output; per-target frozen MSA (panel_msa/<name>.a3m, reused across
panels); same eval/diagnose scripts.

**Changes, with justifications:**

1. **Dose ladder instead of single arms**: alpha in {2.5, 1.5, 0.5, 0.25}
   x 5 seeds, plus the alpha=1 point from the 3-seed stock screen (23
   dose-seed points per target). Justification: the scope claim is about
   monotone steerability, which a single damp strength cannot show; the
   ladder is the advisor-suggested design (2026-10-14), restricted to a
   fixed, class-stratified target list rather than "first 12 that pass".
2. **No reach gate at planning time.** Panels 1-2 skip arms toward
   unreachable basins; panel 3 must NOT skip, because the predictions for
   classes B and C are null predictions that can only be confirmed by
   running the ladder. The ladder runs on every screened target.
3. **No contra/healthy arms, no degrade arm.** The dose ladder subsumes
   both directions; healthy no-harm was a panel-2 transporter question.

## 4. Analysis plan (frozen)

`./panel/run_panel3.sh analyze` -> `panel/analyze_panel3.py`:

- per target: frac_ref1 at each of the 23 dose-seed points; Spearman
  rho vs log2(alpha); permutation p (20,000 shuffles, fixed seed 0);
  Delta between extreme doses; per-target verdict vs its class
  prediction;
- E1, E2, E3 as defined in section 2 (class-A tally / class-B+C tally /
  reachability), with the per-target table written to
  `panel/panel3_summary.csv`;
- dev cases (mbp, kaib) printed descriptively.

Any analysis beyond this file is labelled exploratory and post-hoc.

## 5. Freeze procedure

1. Commit this file + `targets3.csv` + `run_panel3.sh` +
   `analyze_panel3.py` + `make_manifest3.py` + `submit_panel3.sh` +
   `fetch_report3_dev.csv`. (This commit is the prospective timestamp.)
2. Fetch: COMPLETE as of this commit (see sec. 1, gate result) —
   `fetch_report3.csv`, `yamls/<name>.yaml` and
   `panel_data/<name>_ref{1,2}.pdb` for the six ready-status targets are
   committed with this registration. Re-running `PHASE=fetch` on the HPC
   reproduces them byte-identically once login-node network works.
3. `qsub -v PHASE=screen submit_panel3.sh`.
4. `python3 panel/make_manifest3.py` — write the panel-3 freeze
   (inputs + frozen MSAs); commit `MANIFEST3.md5`.
5. `qsub -v PHASE=ladder submit_panel3.sh`, then
   `qsub -v PHASE=analyze submit_panel3.sh`.
6. Copy all eval CSVs, job logs, and the new `panel_msa/*.a3m` back into
   the repo (scratch purges at 30 days); commit.

## 6. Post-archival fields (fill in after tagging; this file stays unpinned)

- Repo URL:
- Release / tag: panel-v4 (created after step 4)
- Zenodo DOI:
- Registration date:
