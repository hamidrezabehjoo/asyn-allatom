#!/usr/bin/env python3
"""Panel-3 analysis: registered scope-condition test (PANEL3_REGISTRATION.md).

Claim under test (frozen before data): a target is controllable by
nu-scheduling iff (i) its two reference states differ by hinge-like motion
with conserved secondary structure (class A: f_ss < 0.15, no buried
ligand) and (ii) both basins are populated in the stock ensemble.
Class C (hinge + buried ligand, PotF precedent) and class B (refold,
f_ss >= 0.15, rfah precedent) predict failure.

Per target, the statistic is the dose-response of the ref1-basin
(open/extended/ground) occupancy over the registered ladder
alpha in {2.5, 1.5, 1, 0.5, 0.25} (alpha=1 = the 3-seed stock screen;
23 dose-seed points per target):

  E1  class A: one-sided permutation p < 0.05 on Spearman(frac_ref1,
      log2 alpha) AND Delta = frac_ref1(2.5) - frac_ref1(0.25) >= 0.10.
      E1 passes iff ALL class-A tally targets are individually
      significant AND the Fisher-combined p < 0.05.
  E2  class B/C: no target shows a significant response (two-sided
      permutation p, Holm within the B+C tally, AND |Delta| >= 0.10).
      E2 passes iff zero violations.
  E3  reachability sub-predictions (stock screen, 300 samples):
      class A: both basins >= 5%; class B/C: ref2 basin < 5%.
      Exact binomial vs chance over the tally.

Dev rows (set=dev: mbp, kaib) are computed identically, printed
descriptively, and never enter E1/E2/E3.

Usage:
    python3 panel/analyze_panel3.py --targets panel/targets3.csv
"""

import argparse
import csv
import glob
import math
import os
import random

TM_BASIN, TM_MARGIN = 0.5, 0.15
DOSES = [2.5, 1.5, 0.5, 0.25]          # alpha=1 comes from the stock screen
MIN_EFFECT = 0.10                       # registered extreme-dose floor
N_PERM = 20000
REACH_FRAC = 0.05                       # basin-populated threshold (E3)


def basins_from_csv(path, foldswitch):
    out = []
    with open(path) as f:
        for r in csv.DictReader(f):
            if foldswitch:
                t1, t2 = float(r["tm_open"]), float(r["tm_closed"])
                if t1 >= TM_BASIN and t1 - t2 >= TM_MARGIN:
                    out.append("open")
                elif t2 >= TM_BASIN and t2 - t1 >= TM_MARGIN:
                    out.append("closed")
                else:
                    out.append("intermediate/other")
            else:
                out.append(r["basin"])
    return out


def frac(b, key):
    return b.count(key) / len(b) if b else float("nan")


def spearman(x, y):
    """Spearman rank correlation (average ranks for ties)."""
    n = len(x)
    if n < 3:
        return float("nan")
    def rank(v):
        order = sorted(range(n), key=lambda i: v[i])
        r = [0.0] * n
        i = 0
        while i < n:
            j = i
            while j + 1 < n and v[order[j + 1]] == v[order[i]]:
                j += 1
            for k in range(i, j + 1):
                r[order[k]] = (i + j) / 2.0 + 1.0
            i = j + 1
        return r
    rx, ry = rank(x), rank(y)
    mx, my = sum(rx) / n, sum(ry) / n
    cov = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    vx = sum((a - mx) ** 2 for a in rx)
    vy = sum((b - my) ** 2 for b in ry)
    return (cov / math.sqrt(vx * vy)) if vx > 0 and vy > 0 else float("nan")


def dose_tag(d):
    return "a" + format(int(round(d * 100)), "03d")


def load_points(name, seeds, ctrl_seeds, foldswitch):
    """Return (xs, ys, per_dose) with x=log2(alpha), y=frac_ref1."""
    xs, ys, per_dose = [], [], {}
    for s in seeds:  # alpha = 1 (stock screen)
        p = f"eval_{name}_stock_s{s}.csv"
        if os.path.exists(p):
            b = basins_from_csv(p, foldswitch)
            xs.append(0.0)
            ys.append(frac(b, "open"))
            per_dose.setdefault(1.0, []).append(frac(b, "open"))
    for d in DOSES:
        for s in ctrl_seeds:
            p = f"eval_{name}_{dose_tag(d)}_s{s}.csv"
            if os.path.exists(p):
                b = basins_from_csv(p, foldswitch)
                xs.append(math.log2(d))
                ys.append(frac(b, "open"))
                per_dose.setdefault(d, []).append(frac(b, "open"))
    return xs, ys, per_dose


def perm_p(xs, ys, rho_obs, n_perm=N_PERM, seed=0):
    rng = random.Random(seed)
    cnt_one = cnt_two = 0
    for _ in range(n_perm):
        rp = spearman(xs, rng.sample(ys, len(ys)))
        if rp != rp:      # constant draw: no correlation information
            continue
        if rp >= rho_obs - 1e-12:
            cnt_one += 1
        if abs(rp) >= abs(rho_obs) - 1e-12:
            cnt_two += 1
    return (1 + cnt_one) / (1 + n_perm), (1 + cnt_two) / (1 + n_perm)


def fisher_sf(ps):
    """Survival function of Fisher's combined statistic (-2 sum ln p)."""
    k = len(ps)
    x = -2.0 * sum(math.log(max(p, 1.0 / (1 + N_PERM))) for p in ps)
    t = 1.0
    s = 1.0
    for j in range(1, k):
        t *= (x / 2.0) / j
        s += t
    return math.exp(-x / 2.0) * s


def binom_ge(k, n):
    return sum(math.comb(n, i) for i in range(k, n + 1)) / (2 ** n)


def holm_flags(items):
    """items: list of (name, p). Return set of names significant after Holm."""
    m = len(items)
    ordered = sorted(items, key=lambda t: t[1])
    sig = set()
    for i, (nm, p) in enumerate(ordered):
        if p < 0.05 / (m - i):
            sig.add(nm)
        else:
            break
    return sig


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--targets", required=True)
    ap.add_argument("--seeds", nargs="+", default=["42", "1", "2"])
    ap.add_argument("--ctrl_seeds", nargs="+", default=["42", "1", "2", "7", "13"])
    ap.add_argument("--diag", default=os.path.join("panel", "panel3_diagnosis.csv"))
    ap.add_argument("--fetch_report", default=os.path.join("panel", "fetch_report3.csv"))
    ap.add_argument("--out", default=os.path.join("panel", "panel3_summary.csv"))
    args = ap.parse_args()

    meta = {r["name"]: r for r in csv.DictReader(open(args.targets))}
    refrmsd = {}
    if os.path.exists(args.fetch_report):
        for r in csv.DictReader(open(args.fetch_report)):
            try:
                refrmsd[r["name"]] = float(r["ref_rmsd"])
            except (ValueError, KeyError):
                pass

    rows = []
    for name, m in meta.items():
        if m["status"] not in ("ready", "dev"):
            continue
        foldswitch = m["foldswitch"] == "1"
        cls = m.get("class", "?")
        stock_csvs = sorted(glob.glob(f"eval_{name}_stock_s*.csv"))
        if not stock_csvs:
            print(f"[skip] {name}: no screen data")
            continue
        stock = []
        for p in stock_csvs:
            stock += basins_from_csv(p, foldswitch)
        fr1, fr2 = frac(stock, "open"), frac(stock, "closed")

        xs, ys, per_dose = load_points(name, args.seeds, args.ctrl_seeds, foldswitch)
        n_pts = len(xs)
        if n_pts >= 10 and len(set(ys)) > 1:
            rho = spearman(xs, ys)
            p_one, p_two = perm_p(xs, ys, rho)
        else:
            rho, p_one, p_two = float("nan"), 1.0, 1.0
        hi = per_dose.get(max(DOSES), [])
        lo = per_dose.get(min(DOSES), [])
        delta = (sum(hi) / len(hi) - sum(lo) / len(lo)) if hi and lo else float("nan")

        # reachability observation vs registered class prediction (E3)
        if cls == "A":
            reach_pred = "both>=5%"
            reach_ok = fr1 >= REACH_FRAC and fr2 >= REACH_FRAC
        elif cls in ("B", "C"):
            reach_pred = "ref2<5%"
            reach_ok = fr2 < REACH_FRAC
        else:
            reach_pred = "?"
            reach_ok = None

        sig_a = (cls == "A" and p_one < 0.05 and delta == delta and delta >= MIN_EFFECT)
        resp_bc = (cls in ("B", "C") and delta == delta and abs(delta) >= MIN_EFFECT)

        rows.append(dict(name=name, set=m["set"], cls=cls,
                         length=m["length"], ref_rmsd=f"{refrmsd.get(name, float('nan')):.2f}",
                         n_points=n_pts, stock_ref1=f"{fr1:.3f}", stock_ref2=f"{fr2:.3f}",
                         rho=(f"{rho:+.3f}" if rho == rho else "nan"),
                         p_one=f"{p_one:.4f}", p_two=f"{p_two:.4f}",
                         delta=(f"{delta:+.3f}" if delta == delta else "nan"),
                         reach_pred=reach_pred,
                         reach_observed=(f"ref1={fr1:.3f} ref2={fr2:.3f}"),
                         reach_correct=("" if reach_ok is None else ("yes" if reach_ok else "no")),
                         _p_one=p_one, _p_two=p_two, _sig_a=sig_a,
                         _resp_bc=resp_bc, _reach_ok=reach_ok))

    fields = ["name", "set", "cls", "length", "ref_rmsd", "n_points",
              "stock_ref1", "stock_ref2", "rho", "p_one", "p_two", "delta",
              "reach_pred", "reach_observed", "reach_correct"]
    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in sorted(rows, key=lambda r: (r["set"] != "scope3", r["cls"], r["name"])):
            w.writerow(r)

    tally = [r for r in rows if r["set"] == "scope3"]
    dev = [r for r in rows if r["set"] == "dev"]

    print("\n================ PANEL-3 SCOPE TEST ================")
    print(f"targets with data: {len(rows)} (tally {len(tally)}, dev {len(dev)})")
    print(f"{'name':10s} {'cls':>3s} {'n':>3s} {'stock r1/r2':>12s} {'rho':>7s} "
          f"{'p1':>7s} {'p2':>7s} {'delta':>7s}  reach")
    for r in sorted(rows, key=lambda r: (r["set"] != "scope3", r["cls"], r["name"])):
        print(f"{r['name']:10s} {r['cls']:>3s} {r['n_points']:>3d} "
              f"{r['stock_ref1'] + '/' + r['stock_ref2']:>12s} {r['rho']:>7s} "
              f"{r['p_one']:>7s} {r['p_two']:>7s} {r['delta']:>7s}  {r['reach_correct']}")

    # ---- E1: class-A controllability ----
    ca = [r for r in tally if r["cls"] == "A"]
    if ca:
        k_ok = sum(r["_sig_a"] for r in ca)
        pf = fisher_sf([r["_p_one"] for r in ca])
        print(f"\nE1 CLASS-A CONTROLLABLE: {k_ok}/{len(ca)} individually significant "
              f"(one-sided p<0.05 & Delta>=0.10); Fisher combined p={pf:.4f} "
              f"-> {'PASS' if k_ok == len(ca) and pf < 0.05 else 'FAIL'}")
        for r in ca:
            print(f"   {r['name']}: rho={r['rho']} p1={r['p_one']} delta={r['delta']} "
                  f"{'significant' if r['_sig_a'] else 'NOT significant'}")
    else:
        print("\nE1: no class-A tally targets with data - inconclusive")

    # ---- E2: scope boundary (B/C must be flat) ----
    bc = [r for r in tally if r["cls"] in ("B", "C")]
    if bc:
        holm = holm_flags([(r["name"], r["_p_two"]) for r in bc])
        viol = [r["name"] for r in bc if r["name"] in holm and r["_resp_bc"]]
        print(f"\nE2 SCOPE BOUNDARY: {len(bc)} class-B/C tally targets, "
              f"violations after Holm + effect floor: {viol or 'none'} "
              f"-> {'PASS' if not viol else 'FAIL (scope rule falsified)'}")
        for r in bc:
            print(f"   {r['name']} ({r['cls']}): rho={r['rho']} p2={r['p_two']} delta={r['delta']}")
    else:
        print("\nE2: no class-B/C tally targets with data - inconclusive")

    # ---- E3: reachability sub-predictions ----
    e3 = [r for r in tally if r["_reach_ok"] is not None]
    if e3:
        k = sum(r["_reach_ok"] for r in e3)
        p_bin = binom_ge(k, len(e3))
        print(f"\nE3 REACHABILITY: {k}/{len(e3)} correct "
              f"(binomial vs chance p={p_bin:.4f})")
        for r in e3:
            print(f"   {r['name']} ({r['cls']}): predicted {r['reach_pred']}, "
                  f"observed {r['reach_observed']} -> {'correct' if r['_reach_ok'] else 'WRONG'}")

    # ---- dev cases (descriptive, outside tallies) ----
    if dev:
        print("\nDEV (outside tallies):")
        for r in dev:
            print(f"   {r['name']} ({r['cls']}): stock ref1/ref2 "
                  f"{r['stock_ref1']}/{r['stock_ref2']}, rho={r['rho']}, "
                  f"p2={r['p_two']}, delta={r['delta']}, reach {r['reach_correct']}")

    print(f"\nwrote {args.out}")


if __name__ == "__main__":
    main()
