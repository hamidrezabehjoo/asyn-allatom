#!/usr/bin/env bash
# Panel-3 driver: registered scope-condition test (7 targets: 5 tally + 2 dev).
# Protocol: panel/PANEL3_REGISTRATION.md (MUST be committed before any run).
# Panel-1 protocol: panel/prospective_test_panel_protocol.md (v2.5).
# Panel-2 registration: panel/PANEL2_REGISTRATION.md.
#
#   ./panel/run_panel3.sh fetch     # sequences, refs, yamls (staged; dev rows skipped)
#   ./panel/run_panel3.sh screen    # stock screen: 100 x 3 seeds per target + diagnosis
#   ./panel/run_panel3.sh ladder    # dose ladder a in {2.5,1.5,0.5,0.25} x 5 seeds, ALL targets
#   ./panel/run_panel3.sh analyze   # scope verdicts (E1 controllable class A / E2 boundary / E3 reachability)
#
# Filters (any phase):   --only name1,name2
# Execution knobs (env): GPUS=1 (screen: split targets across cards)
#                        BOLTZ_EXTRA_ARGS="" (e.g. "--max_parallel_samples 30")
# Frozen (PANEL3_REGISTRATION.md; do NOT change): N=100 STEPS=200
#     SEEDS="42 1 2"  CTRL_SEEDS="42 1 2 7 13"  DOSES="2.5 1.5 0.5 0.25"  NU_TW=0.5
#
# Difference vs panels 1-2 (registered): NO reach gate at planning time -
# class B/C predictions are null predictions and can only be confirmed by
# running the ladder on every screened target.
#
# Per target <name> (same conventions as panels 1-2; names are disjoint
# from panels 1-2 except dev cases mbp/kaib, whose pinned assets are reused):
#   yamls/<name>.yaml                        fetch (staged, then merged)
#   panel_data/<name>_ref1.pdb, _ref2.pdb    fetch (renumbered)
#   panel_msa/<name>.a3m                     screen (MSA frozen for all arms)
#   results_<name>_stock_s<seed>/            screen
#   results_<name>_a{025,050,150,250}_s<seed>/   ladder arms
#   eval_<name>_stock_s<seed>.csv, eval_<name>_a<dose>_s<seed>.csv
#   panel/panel3_diagnosis.csv, panel/panel3_summary.csv
#   panel/fetch_report3.csv (+ static dev rows from fetch_report3_dev.csv)
#
# Prerequisites: patched Boltz-2 env (diffusionv2.py must contain NU_ALPHA;
# checked before the ladder phase).

set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PHASE="${1:-}"
ONLY=""
shift || true
while [ $# -gt 0 ]; do
    case "$1" in
        --only) ONLY="$2"; shift 2 ;;
        *) echo "unknown option $1" >&2; exit 1 ;;
    esac
done

TARGETS_CSV="panel/targets3.csv"
DIAG_CSV="panel/panel3_diagnosis.csv"
FETCH_REP="panel/fetch_report3.csv"
FETCH_REP_DEV="panel/fetch_report3_dev.csv"
SUMMARY_CSV="panel/panel3_summary.csv"

N=${N:-100}; STEPS=${STEPS:-200}
SEEDS=${SEEDS:-"42 1 2"}                    # stock screen (diagnosis)
CTRL_SEEDS=${CTRL_SEEDS:-"42 1 2 7 13"}     # ladder arms
DOSES=${DOSES:-"2.5 1.5 0.5 0.25"}          # frozen ladder (alpha=1 = screen stock)
BOLTZ_EXTRA_ARGS=${BOLTZ_EXTRA_ARGS:-""}

BIGCACHE="${BIGCACHE:-$HOME}"
export BOLTZ_CACHE="${BOLTZ_CACHE:-$BIGCACHE/boltz_cache}"
export TRITON_CACHE_DIR="${TRITON_CACHE_DIR:-$BIGCACHE/triton_cache}"
export TORCHINDUCTOR_CACHE_DIR="${TORCHINDUCTOR_CACHE_DIR:-$BIGCACHE/torchinductor_cache}"
export CUDA_CACHE_PATH="${CUDA_CACHE_PATH:-$BIGCACHE/cuda_cache}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$BIGCACHE/xdg_cache}"
mkdir -p "$BOLTZ_CACHE" panel_msa

# screen + ladder run tally (ready) and dev targets; fetch skips dev rows
# itself (fetch_panel.py processes only status=ready; dev assets already
# exist in the repo and are pinned).
TARGETS=$(python3 - "$ONLY" <<'EOF'
import csv, sys
only = set(sys.argv[1].split(",")) if sys.argv[1] else None
for r in csv.DictReader(open("panel/targets3.csv")):
    if r["status"] not in ("ready", "dev"):
        continue
    if only and r["name"] not in only:
        continue
    print(r["name"], r["foldswitch"], r["expected_state"])
EOF
)
[ -n "$TARGETS" ] || { echo "no targets selected" >&2; exit 1; }

yaml_of()    { echo "yamls/$1.yaml"; }
pred_dir()   { echo "$1/boltz_results_$2/predictions/$2"; }
# boltz names output dirs after the YAML filename STEM (see run_panel.sh).
yaml_stem() { local b; b=$(basename "$1"); echo "${b%.yaml}"; }
basin_rule() { [ "$2" = "1" ] && echo tm || echo rmsd; }

dose_tag() { # 2.5 -> a250, 0.25 -> a025
    python3 -c "print('a' + format(int(round(float('$1')*100)), '03d'))"
}

run_eval() { # $1 results dir, $2 name, $3 foldswitch, $4 tag, $5 yaml stem
    python3 panel/eval_panel.py --pred_dir "$(pred_dir "$1" "$5")" \
        --ref1 "panel_data/$2_ref1.pdb" --ref2 "panel_data/$2_ref2.pdb" \
        --basin_rule "$(basin_rule "$2" "$3")" --escape_rmsd auto \
        --tag "$4" --out "eval_$2_$4.csv"
}

patch_gate() {
    local f n
    f=$(python3 -c "import boltz, os; print(os.path.join(os.path.dirname(boltz.__file__),'model','modules','diffusionv2.py'))")
    n=$(grep -c NU_ALPHA "$f" || true)
    if [ "$n" -eq 0 ]; then
        echo "FATAL: $f has no NU_ALPHA hook - controlled arm would silently be stock." >&2
        echo "Apply the patch first:  cp diffusionv2.py $f" >&2
        exit 1
    fi
}

# freeze the MSA from the first stock run so every later arm of this target
# uses byte-identical evolutionary input (same freeze discipline as panels 1-2)
freeze_msa() { # $1 name, $2 first results dir
    [ -s "panel_msa/$1.a3m" ] && return 0
    local a3m
    a3m=$(find "$2" -name "*.a3m" | head -1 || true)
    if [ -n "$a3m" ]; then
        cp "$a3m" "panel_msa/$1.a3m"
        python3 - "$1" <<'EOF'
import sys
p = f"panel_msa/{sys.argv[1]}.a3m"
d = open(p, "rb").read()
if d.endswith(b"\x00") and d.count(b"\x00") == 1:
    open(p, "wb").write(d[:-1])
    print(f"  freeze_msa: stripped trailing NUL (boltz writer artifact) from {p}")
elif b"\x00" in d:
    print(f"  WARNING: {p} contains NUL bytes beyond the trailing artifact -", file=sys.stderr)
    print(f"  inspect before running arms of this target", file=sys.stderr)
EOF
        echo "  MSA frozen: $(md5sum "panel_msa/$1.a3m" | cut -c1-12) panel_msa/$1.a3m"
    else
        echo "  WARNING: no .a3m found under $2 - ladder arms will call the MSA server again" >&2
    fi
}

# yaml with the frozen MSA wired in; sets MSA_YAML and MSA_FLAG. Must NOT
# be called via $(...) (subshell loses the flag; see run_panel.sh).
msa_yaml() { # $1 name
    if [ -s "panel_msa/$1.a3m" ]; then
        if python3 -c "import sys; sys.exit(1 if b'\x00' in open('panel_msa/$1.a3m','rb').read() else 0)"; then
            sed "/      sequence:/a\\      msa: panel_msa/$1.a3m" "$(yaml_of "$1")" > "yamls/$1.msa.yaml"
            MSA_YAML="yamls/$1.msa.yaml"; MSA_FLAG=""
        else
            echo "  CORRUPT: panel_msa/$1.a3m has NUL bytes - repair or re-fetch, then rerun" >&2
            MSA_YAML=""; MSA_FLAG=""
        fi
    else
        MSA_YAML=$(yaml_of "$1"); MSA_FLAG="--use_msa_server"
    fi
}

run_arm() { # $1 name, $2 foldswitch, $3 tag(e.g. a025), $4 alpha
    local name=$1 fs=$2 tag=$3 alpha=$4
    local y mf stem
    msa_yaml "$name"; y=$MSA_YAML; mf=$MSA_FLAG; stem=$(yaml_stem "$y")
    [ -n "$y" ] || { echo "[skip] $name $tag: frozen MSA corrupt (see above)"; return 1; }
    for s in $CTRL_SEEDS; do
        if [ -s "eval_${name}_${tag}_s${s}.csv" ]; then
            echo "[skip] $name $tag seed $s: exists"; continue
        fi
        local res="results_${name}_${tag}_s${s}"
        if [ -d "$(pred_dir "$res" "$stem")" ]; then
            echo "[reuse] $name $tag seed $s: predictions exist, eval only"
        else
            echo "=== $name $tag alpha=$alpha tw=0.5 seed $s ==="
            NU_ALPHA="$alpha" NU_TW=0.5 \
            boltz predict "$y" $mf --use_potentials < /dev/null \
                --diffusion_samples "$N" --sampling_steps "$STEPS" $BOLTZ_EXTRA_ARGS \
                --output_format pdb --seed "$s" --cache "$BOLTZ_CACHE" \
                --out_dir "$res" --override \
                || { echo "[FAIL boltz] $name $tag seed $s"; continue; }
        fi
        run_eval "$res" "$name" "$fs" "${tag}_s${s}" "$stem" \
            || echo "[FAIL eval] $name $tag seed $s"
    done
}

case "$PHASE" in

fetch)
    # Staged fetch (same pattern as panel 2): fetch_panel.py rewrites
    # panel/fetch_report.csv (pinned panel-1 file), so it must NOT run
    # with --root . . Fetch into staging, merge NEW files only.
    # dev rows (mbp, kaib) are skipped by fetch_panel.py (status!=ready);
    # their pinned panel-1/dev assets are reused and their report rows come
    # from panel/fetch_report3_dev.csv (static, pinned).
    STAGE="${TMPDIR:-/tmp}/panel3_fetch"
    rm -rf "$STAGE"; mkdir -p "$STAGE/panel"
    python3 panel/fetch_panel.py --targets "$TARGETS_CSV" --root "$STAGE" --include-optional ${ONLY:+--only $ONLY}
    [ -f "$STAGE/panel/fetch_report.csv" ] || { echo "fetch produced no report" >&2; exit 1; }
    ( cd "$STAGE" && find yamls panel_data -type f 2>/dev/null | while read -r f; do
        case "$f" in panel_data/pdb_cache/*) continue ;; esac
        if [ -e "$ROOT/$f" ]; then
            cmp -s "$f" "$ROOT/$f" || { echo "CONFLICT: $f exists and differs - refusing to overwrite" >&2; exit 1; }
        else
            mkdir -p "$ROOT/$(dirname "$f")"; cp "$f" "$ROOT/$f"
        fi
      done )
    # fetch_report3.csv: staged ready rows + static dev rows
    python3 - "$STAGE/panel/fetch_report.csv" <<'EOF'
import csv, os, sys
fields = ["name","set","L_input","matched_ref1","matched_ref2","shared",
          "id1","id2","ref_rmsd","rmsd_table","warning"]
rows = {}
if os.path.exists("panel/fetch_report3.csv"):
    for r in csv.DictReader(open("panel/fetch_report3.csv")):
        rows[r["name"]] = r
for r in csv.DictReader(open(sys.argv[1])):
    rows[r["name"]] = r
for r in csv.DictReader(open("panel/fetch_report3_dev.csv")):
    rows.setdefault(r["name"], r)   # static fallback only (kaib pre-fetched)
with open("panel/fetch_report3.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
    for n in sorted(rows): w.writerow(rows[n])
print(f"wrote panel/fetch_report3.csv ({len(rows)} targets)")
EOF
    echo
    echo "FETCH GATE: rows with VALIDATION_FAIL must be marked 'excluded' in"
    echo "targets3.csv BEFORE screening (same rule as panel 2, PANEL3_REGISTRATION.md sec.1)."
    ;;

screen)
    N_GPUS=${GPUS:-1}
    TGT="$TARGETS" python3 - "$N_GPUS" <<'EOF'
import csv, os, sys
n = int(sys.argv[1])
length = {r["name"]: int(r["length"]) if r["length"].strip().isdigit() else 0
          for r in csv.DictReader(open("panel/targets3.csv"))}
rows = [l.split() for l in os.environ["TGT"].splitlines() if l.strip()]
load = [0] * n
lists = [[] for _ in range(n)]
for r in sorted(rows, key=lambda r: -length.get(r[0], 0)):
    i = min(range(n), key=lambda j: load[j])
    lists[i].append(" ".join(r))
    load[i] += length.get(r[0], 0)
for i, lst in enumerate(lists):
    with open(f"/tmp/panel3_screen_w{i}.txt", "w") as fh:
        fh.write("\n".join(lst) + ("\n" if lst else ""))
    print(f"worker {i}: {[l.split()[0] for l in lst]} (load {load[i]} res)", file=sys.stderr)
EOF

    screen_worker() { # $1 worker list file
        while read -r name fs exp <&3; do
            [ -f "$(yaml_of "$name")" ] || { echo "[skip] $name: $(yaml_of "$name") missing (run fetch)"; continue; }
            # MSA strategy (same as panel 2, execution-only): reuse the
            # frozen MSA when present; only targets without one call the
            # ColabFold server. Freezing from the FIRST successful seed
            # makes progress accumulate across resubmissions. MSA content
            # is unchanged - same server, same sequence.
            msa_yaml "$name"; y=$MSA_YAML; mf=$MSA_FLAG
            [ -n "$y" ] || { echo "[skip] $name: frozen MSA corrupt"; continue; }
            stem=$(yaml_stem "$y")
            for s in $SEEDS; do
                if [ -s "eval_${name}_stock_s${s}.csv" ]; then
                    echo "[skip] $name seed $s: screen CSV exists"; continue
                fi
                echo "=== screen $name (seed $s, $N samples, gpu ${CUDA_VISIBLE_DEVICES:-default}) ==="
                boltz predict "$y" $mf --use_potentials < /dev/null \
                    --diffusion_samples "$N" --sampling_steps "$STEPS" $BOLTZ_EXTRA_ARGS \
                    --output_format pdb --seed "$s" --cache "$BOLTZ_CACHE" \
                    --out_dir "results_${name}_stock_s${s}" --override \
                    || { echo "[FAIL boltz] $name seed $s"; continue; }
                run_eval "results_${name}_stock_s${s}" "$name" "$fs" "stock_s${s}" "$stem" \
                    || { echo "[FAIL eval] $name seed $s"; continue; }
                freeze_msa "$name" "results_${name}_stock_s${s}"
            done
        done 3< "$1"
    }

    if [ "$N_GPUS" -le 1 ]; then
        screen_worker /tmp/panel3_screen_w0.txt
    else
        PIDS=""
        for i in $(seq 0 $((N_GPUS-1))); do
            ( export CUDA_VISIBLE_DEVICES=$i; screen_worker "/tmp/panel3_screen_w$i.txt" ) \
                > "screen3_gpu$i.log" 2>&1 &
            PIDS="$PIDS $!"
            echo "[worker $i] GPU $i -> screen3_gpu$i.log (pid $!)"
        done
        rc=0
        for p in $PIDS; do wait "$p" || rc=1; done
        for i in $(seq 0 $((N_GPUS-1))); do
            echo "[worker $i] failures: $(grep -c '^\[FAIL' "screen3_gpu$i.log" 2>/dev/null || true) (screen3_gpu$i.log)"
        done
        [ "$rc" -eq 0 ] || echo "WARNING: a worker exited non-zero; check screen3_gpu*.log" >&2
    fi

    # Serial diagnosis pass (descriptive in panel 3 - the registered
    # endpoint is the ladder slope, not the damp/boost verdict).
    while read -r name fs exp <&3; do
        csvs=""; dirs=""; missing=0
        for s in $SEEDS; do
            csvs="$csvs eval_${name}_stock_s${s}.csv"
            dirs="$dirs $(pred_dir results_${name}_stock_s${s} "$name")"
            [ -s "eval_${name}_stock_s${s}.csv" ] || missing=1
        done
        if [ "$missing" -eq 1 ]; then
            echo "[incomplete] $name: seed CSV(s) missing - rerun screen to retry (log above / screen3_gpu*.log)"
            continue
        fi
        python3 panel/panel_diagnose.py --name "$name" \
            --csvs $csvs --pred_dirs $dirs \
            --basin_rule "$(basin_rule "$name" "$fs")" \
            --expected "$([ "$exp" = "ref2" ] && echo closed || echo open)" \
            --out "diagnosis_${name}.txt" \
            --report_csv "$DIAG_CSV"
    done 3<<< "$TARGETS"
    echo; echo "=== screen done; $DIAG_CSV: ==="
    column -s, -t "$DIAG_CSV" 2>/dev/null || cat "$DIAG_CSV"
    ;;

ladder)
    patch_gate
    # NO reach gate (registered): the ladder runs on every screened target,
    # because class B/C predictions are null predictions.
    while read -r name fs exp <&3; do
        [ -f "$(yaml_of "$name")" ] || { echo "[skip] $name: yaml missing (run fetch)"; continue; }
        for dose in $DOSES; do
            run_arm "$name" "$fs" "$(dose_tag "$dose")" "$dose"
        done
    done 3<<< "$TARGETS"
    echo "ladder done. Next: ./panel/run_panel3.sh analyze"
    ;;

analyze)
    python3 panel/analyze_panel3.py --targets "$TARGETS_CSV" \
        --diag "$DIAG_CSV" --fetch_report "$FETCH_REP" --out "$SUMMARY_CSV" \
        --seeds $SEEDS --ctrl_seeds $CTRL_SEEDS
    ;;

*)
    echo "usage: $0 {fetch|screen|ladder|analyze} [--only a,b]" >&2
    echo "  env knobs: GPUS=N (screen: split targets across N cards), BOLTZ_EXTRA_ARGS, N, SEEDS, CTRL_SEEDS" >&2
    echo "  frozen by registration: DOSES=\"2.5 1.5 0.5 0.25\" NU_TW=0.5" >&2
    exit 1 ;;
esac
