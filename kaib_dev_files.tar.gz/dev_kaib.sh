#!/usr/bin/env bash
# dev_kaib.sh -- EXPLORATORY KaiB fold-switch test (dev case).
# NOT part of panel-2 or panel-3 registered tallies: tags are dev_*,
# kaib is not in targets2.csv, and analyze never globs these files.
# Refs: ref1=2QKE_A (ground state, NMR medoid), ref2=5JYT_A (fold-switched).
# Basin rule: TM (fold-switch). Expected state: ref2 (fold-switch).
set -uo pipefail
cd "${REPO:-$HOME/scratch/OC}"
N=100; STEPS=200; SEEDS="42 1 2"; CTRL_SEEDS="42 1 2 7 13"
CACHE="${BOLTZ_CACHE:-/scratch/users/industry/ism/behjoo/boltz_cache}"

EVAL() { # $1 results dir, $2 tag, $3 yaml stem
  python3 panel/eval_panel.py --pred_dir "$1/boltz_results_$3/predictions/$3" \
    --ref1 panel_data/kaib_ref1.pdb --ref2 panel_data/kaib_ref2.pdb \
    --basin_rule tm --escape_rmsd auto --tag "$2" --out "eval_kaib_$2.csv"
}

# 1. stock screen (3 seeds) + freeze MSA from first success
for s in $SEEDS; do
  [ -s "eval_kaib_dev_stock_s${s}.csv" ] && { echo "[skip] stock s$s"; continue; }
  echo "=== kaib dev stock seed $s ==="
  boltz predict yamls/kaib.yaml --use_msa_server --use_potentials \
    --diffusion_samples $N --sampling_steps $STEPS ${BOLTZ_EXTRA_ARGS:-} \
    --output_format pdb --seed "$s" --cache "$CACHE" \
    --out_dir "results_kaib_dev_stock_s$s" --override || { echo "[FAIL] stock s$s"; continue; }
  EVAL "results_kaib_dev_stock_s$s" "dev_stock_s$s" kaib
  if [ ! -s panel_msa/kaib.a3m ]; then
    a=$(find "results_kaib_dev_stock_s$s" -name "*.a3m" | head -1)
    if [ -n "$a" ]; then
      cp "$a" panel_msa/kaib.a3m
      python3 -c "
d=open('panel_msa/kaib.a3m','rb').read()
if d.endswith(b'\x00') and d.count(b'\x00')==1: open('panel_msa/kaib.a3m','wb').write(d[:-1])
"
      echo "MSA frozen: $(md5sum panel_msa/kaib.a3m | cut -c1-12) ($(grep -c '^>' panel_msa/kaib.a3m) seqs)"
    fi
  fi
done

[ -s panel_msa/kaib.a3m ] || { echo "no frozen MSA - rerun; server must answer once"; exit 1; }
sed "/      sequence:/a\\      msa: panel_msa/kaib.a3m" yamls/kaib.yaml > yamls/kaib.msa.yaml

# 2. arms (both directions, exploratory): damp a=0.25 and boost a=2.5
for spec in "damp 0.25" "boost 2.5"; do
  set -- $spec; tag=$1; alpha=$2
  for s in $CTRL_SEEDS; do
    [ -s "eval_kaib_dev_${tag}_s${s}.csv" ] && { echo "[skip] $tag s$s"; continue; }
    echo "=== kaib dev $tag alpha=$alpha seed $s ==="
    NU_ALPHA=$alpha NU_TW=0.5 boltz predict yamls/kaib.msa.yaml --use_potentials \
      --diffusion_samples $N --sampling_steps $STEPS ${BOLTZ_EXTRA_ARGS:-} \
      --output_format pdb --seed "$s" --cache "$CACHE" \
      --out_dir "results_kaib_dev_${tag}_s$s" --override || { echo "[FAIL] $tag s$s"; continue; }
    EVAL "results_kaib_dev_${tag}_s$s" "dev_${tag}_s$s" kaib.msa
  done
done

echo "== done =="; ls eval_kaib_dev_*.csv 2>/dev/null
